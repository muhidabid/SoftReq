This data is part of the OpenScience tera-PROMISE repository, a long-term hosting 
solution for software engineering research data.

More information about this dataset can be found at http://openscience.us/repo/requirements/other-requirements/nfr
